package com.moja.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AlarmStore {
    private const val PREF = "moja_alarm_native_v1"
    private const val CONFIG = "config"
    private const val SESSION = "session"
    fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun config(c: Context): JSONObject = runCatching { JSONObject(prefs(c).getString(CONFIG, "{}") ?: "{}") }.getOrDefault(JSONObject())
    fun saveConfig(c: Context, obj: JSONObject) { prefs(c).edit().putString(CONFIG, obj.toString()).apply() }
    fun session(c: Context): JSONObject = runCatching { JSONObject(prefs(c).getString(SESSION, "{}") ?: "{}") }.getOrDefault(JSONObject())
    fun saveSession(c: Context, obj: JSONObject) { prefs(c).edit().putString(SESSION, obj.toString()).apply() }
    fun clearSession(c: Context) { prefs(c).edit().remove(SESSION).apply() }
    fun challenges(config: JSONObject = JSONObject()): List<String> { val a=config.optJSONArray("challenges") ?: JSONArray(); return (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }.distinct() }
}
