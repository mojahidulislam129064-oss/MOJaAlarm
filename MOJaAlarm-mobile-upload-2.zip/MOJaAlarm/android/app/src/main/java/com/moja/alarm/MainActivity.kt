package com.moja.alarm

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(MojaAlarmPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
