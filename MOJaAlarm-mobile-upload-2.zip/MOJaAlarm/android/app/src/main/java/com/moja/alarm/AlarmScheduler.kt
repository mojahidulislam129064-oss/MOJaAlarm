package com.moja.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

object AlarmScheduler {
    private const val REQUEST_BASE = 7410
    fun schedule(context: Context, config: JSONObject): String {
        val manager = context.getSystemService(AlarmManager::class.java)
        if (!config.optBoolean("enabled", false)) { cancel(context); return "Alarm disabled." }
        if (AlarmStore.challenges(config).isEmpty()) throw IllegalArgumentException("Select at least one challenge before enabling the alarm.")
        if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) throw SecurityException("Exact alarm permission is not granted. Enable Alarms & reminders in Android settings.")
        val time = config.optString("time", "07:00").split(":")
        if (time.size != 2) throw IllegalArgumentException("Invalid alarm time.")
        val hour=time[0].toIntOrNull() ?: throw IllegalArgumentException("Invalid hour")
        val minute=time[1].toIntOrNull() ?: throw IllegalArgumentException("Invalid minute")
        if (hour !in 0..23 || minute !in 0..59) throw IllegalArgumentException("Invalid alarm time.")
        val weekdays=config.optJSONArray("weekdays") ?: config.optJSONArray("days")
        val days=(0 until (weekdays?.length() ?: 0)).mapNotNull { weekdays?.optInt(it) }.filter { it in 0..6 }.toSet()
        val next=nextTime(hour,minute,days)
        val pi=pendingIntent(context,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val info=AlarmManager.AlarmClockInfo(next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), showIntent(context))
        manager.setAlarmClock(info,pi)
        AlarmStore.saveConfig(context,config.put("nextTriggerAt",info.triggerTime))
        return "Exact alarm scheduled for ${next} (${ZoneId.systemDefault()})."
    }
    private fun nextTime(hour:Int,minute:Int,days:Set<Int>):LocalDateTime {
        val now=LocalDateTime.now(); var candidate=now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if(days.isEmpty()) { if(!candidate.isAfter(now)) candidate=candidate.plusDays(1); return candidate }
        for(i in 0..7){val d=candidate.plusDays(i.toLong()); if(d.isAfter(now)&&days.contains(d.dayOfWeek.value%7))return d}
        return candidate.plusDays(1)
    }
    fun cancel(context: Context) { context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)); AlarmStore.saveConfig(context,AlarmStore.config(context).put("enabled",false)) }
    private fun pendingIntent(c:Context,flags:Int)=PendingIntent.getBroadcast(c,REQUEST_BASE,Intent(c,AlarmReceiver::class.java).setAction("com.moja.alarm.TRIGGER"),flags)
    private fun showIntent(c:Context)=PendingIntent.getActivity(c,REQUEST_BASE+1,Intent(c,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun reschedule(context:Context) { val config=AlarmStore.config(context); if(config.optBoolean("enabled",false)) runCatching { schedule(context,config) } }
}
