package com.moja.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class RecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when(intent?.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                AlarmScheduler.reschedule(context)
                val session=AlarmStore.session(context)
                if(session.optBoolean("active",false)) {
                    // Recover the existing session; service/player initialization is idempotent.
                    runCatching { context.startForegroundService(Intent(context,AlarmForegroundService::class.java).setAction(AlarmForegroundService.ACTION_RECOVER).putExtra("sessionId",session.optString("id"))) }.onFailure { AlarmStore.saveSession(context, session.put("recoveryError", it.message ?: "OS blocked foreground service recovery")) }
                }
            }
        }
    }
}
