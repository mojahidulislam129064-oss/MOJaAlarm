package com.moja.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val config=AlarmStore.config(context)
        if(!config.optBoolean("enabled",false)) return
        val pending=goAsync()
        try {
            val session=AlarmStore.session(context)
            if(session.optBoolean("active",false)) return
            val id=UUID.randomUUID().toString()
            val challenges=AlarmStore.challenges(config)
            if(challenges.isEmpty()) return
            AlarmStore.saveSession(context,JSONObject().put("id",id).put("active",true).put("state","RINGING").put("startedAt",System.currentTimeMillis()).put("challenges",JSONArray(challenges)).put("completed",JSONArray()))
            context.startForegroundService(Intent(context,AlarmForegroundService::class.java).setAction(AlarmForegroundService.ACTION_START).putExtra("sessionId",id))
            // For a recurring schedule, schedule the next selected weekday after this occurrence.
            if((config.optJSONArray("weekdays")?.length() ?: config.optJSONArray("days")?.length() ?: 0)>0) AlarmScheduler.schedule(context,config)
            else AlarmStore.saveConfig(context,config.put("enabled",false))
        } catch (_: Exception) { AlarmStore.saveSession(context,JSONObject().put("active",false).put("state","ERROR").put("error","Unable to start alarm service")) }
        finally { pending.finish() }
    }
}
