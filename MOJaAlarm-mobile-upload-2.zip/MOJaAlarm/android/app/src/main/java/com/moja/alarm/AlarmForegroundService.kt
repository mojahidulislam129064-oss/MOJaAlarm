package com.moja.alarm

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject

class AlarmForegroundService : Service() {
    companion object {
        const val ACTION_START="com.moja.alarm.START"; const val ACTION_RECOVER="com.moja.alarm.RECOVER"; const val ACTION_STOP_VICTORY="com.moja.alarm.STOP_VICTORY"; const val ACTION_EMERGENCY="com.moja.alarm.EMERGENCY"; const val ACTION_TEST="com.moja.alarm.TEST"; const val ACTION_STOP_TEST="com.moja.alarm.STOP_TEST"
        private const val CHANNEL="moja_alarm_active"; private const val NOTIFICATION_ID=7041
        @Volatile private var player:MediaPlayer?=null
        @Volatile private var testOnly=false
    }
    private var wakeLock:PowerManager.WakeLock?=null
    private var focusRequest:AudioFocusRequest?=null
    private var audioManager:AudioManager?=null
    override fun onCreate(){super.onCreate();createChannel()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        when(intent?.action){
            ACTION_STOP_VICTORY -> { stopAfterVictory(); return START_NOT_STICKY }
            ACTION_EMERGENCY -> { stopEverything(emergency=true); return START_NOT_STICKY }
            ACTION_STOP_TEST -> { if(testOnly) stopEverything(emergency=false); return START_NOT_STICKY }
            ACTION_TEST -> { testOnly=true; startForeground(NOTIFICATION_ID,notification("Test Alarm চলছে")); startAudio(); return START_NOT_STICKY }
            ACTION_START, ACTION_RECOVER -> { testOnly=false; startForeground(NOTIFICATION_ID,notification("MOJa ALARM সক্রিয় — মিশন খুলুন")); acquireWakeLock(); startAudio() }
        }
        return START_STICKY
    }
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26){val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel(CHANNEL,"MOJa ALARM",NotificationManager.IMPORTANCE_HIGH).apply{description="Ongoing alarm session";setSound(null,null);lockscreenVisibility=Notification.VISIBILITY_PUBLIC})}}
    private fun notification(text:String):Notification { val open=PendingIntent.getActivity(this,1,Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val stop=PendingIntent.getService(this,2,Intent(this,AlarmForegroundService::class.java).setAction(ACTION_EMERGENCY),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("MOJa ALARM").setContentText(text).setCategory(NotificationCompat.CATEGORY_ALARM).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOngoing(true).setContentIntent(open).addAction(0,"Emergency stop",stop).build() }
    private fun acquireWakeLock(){if(wakeLock?.isHeld==true)return;wakeLock=getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"MOJaAlarm:RingSession").apply{setReferenceCounted(false);acquire(10*60*1000L)}}
    private fun startAudio(){if(player?.isPlaying==true)return;val am=getSystemService(Context.AUDIO_SERVICE) as AudioManager;audioManager=am;val attrs=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();if(Build.VERSION.SDK_INT>=26){focusRequest=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attrs).setOnAudioFocusChangeListener{change->if(change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) player?.setVolume(.35f,.35f) else if(change==AudioManager.AUDIOFOCUS_GAIN) player?.setVolume(1f,1f)}.build();am.requestAudioFocus(focusRequest!!)}else @Suppress("DEPRECATION") run { am.requestAudioFocus(null,AudioManager.STREAM_ALARM,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT) }
        try { val cfg=AlarmStore.config(this); val custom=cfg.optString("nativeRingtoneUri",""); val mp=MediaPlayer();mp.setAudioAttributes(attrs);if(custom.isNotBlank())mp.setDataSource(this,Uri.parse(custom)) else {val afd=resources.openRawResourceFd(R.raw.fallback_alarm);mp.setDataSource(afd.fileDescriptor,afd.startOffset,afd.length);afd.close()};mp.isLooping=true;mp.setOnErrorListener{_,_,_->AlarmStore.saveSession(this,AlarmStore.session(this).put("audioError","MediaPlayer error"));true};mp.setOnPreparedListener{it.start()};mp.prepareAsync();player=mp }catch(e:Exception){AlarmStore.saveSession(this,AlarmStore.session(this).put("audioError",e.message?:"Playback failed"))}
    }
    private fun stopAfterVictory(){stopEverything(false, preserveSession=true)}
    private fun stopEverything(emergency:Boolean, preserveSession:Boolean=false){synchronized(AlarmForegroundService::class.java){runCatching{player?.stop()};runCatching{player?.release()};player=null};focusRequest?.let{if(Build.VERSION.SDK_INT>=26)audioManager?.abandonAudioFocusRequest(it)};focusRequest=null;wakeLock?.let{if(it.isHeld)it.release()};wakeLock=null;if(emergency)AlarmStore.saveSession(this,JSONObject().put("active",false).put("state","EMERGENCY_STOPPED"))else if(testOnly){}else if(!preserveSession)AlarmStore.clearSession(this);testOnly=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}
    override fun onDestroy(){// Do not release a healthy singleton player solely because the Activity/WebView is recreated.
        super.onDestroy()
    }
    override fun onBind(intent:Intent?):IBinder?=null
}
