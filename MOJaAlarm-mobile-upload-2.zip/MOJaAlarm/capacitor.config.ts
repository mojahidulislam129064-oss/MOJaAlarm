import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.moja.alarm', appName: 'MOJa ALARM', webDir: 'www',
  bundledWebRuntime: false, android: { allowMixedContent: false }
};
export default config;
