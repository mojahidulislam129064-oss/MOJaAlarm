import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const out = resolve(root, 'www');
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const entry of ['index.html', 'assets', 'src']) {
  await cp(resolve(root, entry), resolve(out, entry), { recursive: true });
}
console.log('Web assets staged into www/ for Capacitor.');
