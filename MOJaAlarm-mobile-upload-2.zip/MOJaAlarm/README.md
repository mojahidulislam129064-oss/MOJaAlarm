# MOJa ALARM — hybrid Android source project

Offline-first alarm prototype with an HTML/CSS/vanilla JS dashboard and a Kotlin Capacitor plugin. Native Android owns scheduled alarms and the foreground ringing service; the WebView is only the mission interface.

## Versions and compatibility

- Capacitor `7.4.3` (`@capacitor/core`, `@capacitor/android`, CLI)
- Android Gradle Plugin `8.7.3`, Gradle wrapper expected `8.11.1`
- Kotlin `2.0.21`, Java 17 toolchain
- `compileSdk 35`, `targetSdk 35`, `minSdk 26`
- Android 12+ exact alarms require user-granted Alarms & reminders access; Android 13+ notification permission; Android 14+ full-screen intent access may be restricted.

These are explicit project pins, not a claim that this source has been built on every supported device. This delivery environment has no Android SDK/Gradle wrapper installed, so an APK could not be built here. A compatible Android SDK and internet access are needed once to download build dependencies; runtime core features are designed to work offline.

## Project tree

```text
MOJaAlarm/
├── index.html
├── assets/app.css
├── src/{main.js,db.js,challenges.js,state-machine.js}
├── tests/{challenges.test.js,state-machine.test.js}
├── package.json
├── capacitor.config.ts
└── android/
    ├── settings.gradle, build.gradle, gradle.properties
    └── app/src/main/
        ├── AndroidManifest.xml
        ├── java/com/moja/alarm/
        │   ├── MainActivity.kt
        │   ├── MojaAlarmPlugin.kt
        │   ├── AlarmScheduler.kt
        │   ├── AlarmReceiver.kt
        │   ├── AlarmForegroundService.kt
        │   ├── RecoveryReceiver.kt
        │   └── AlarmStore.kt
        └── res/{raw/fallback_alarm.wav,values/styles.xml}
```

## Build and run

Prerequisites: Node 20+, JDK 17, Android Studio/SDK Platform 35, Build Tools 35.x, and Android SDK command-line tools.

```bash
npm install
npm test
# Generate Capacitor Android project wiring / copy the web assets
npx cap sync android
# Open in Android Studio and let Gradle sync
npx cap open android
```

To build a debug APK after Gradle sync:

```bash
cd android
gradle --version  # use Gradle 8.11.1 with JDK 17
gradle assembleDebug
# output: app/build/outputs/apk/debug/app-debug.apk
```

For a signed release, create a keystore and configure a `signingConfig` in `android/app/build.gradle` without committing secrets, then run `./gradlew assembleRelease`. Verify the APK with `apksigner verify --verbose app/build/outputs/apk/release/app-release.apk`.

## Native alarm lifecycle and audio invariants

1. `MojaAlarmPlugin.scheduleAlarm` validates and persists the configuration, then `AlarmScheduler` schedules an `AlarmClockInfo` through `AlarmManager`.
2. `AlarmReceiver` checks the enabled config and existing session before creating one session ID and starting `AlarmForegroundService`.
3. The foreground service owns a looping `MediaPlayer` and a bounded partial wake lock. The player is static within the service process and is not controlled by WebView route/modal lifecycle.
4. WebView reload asks for status/recovery and reconnects to the native session. Wrong answers and challenge UI changes do not invoke stop.
5. `stopAlarmAfterVictory` checks session ID, configured challenge set, result count and basic result schema, persists the victory state, then sends the stop action. The operation is session-bound and idempotent for a recorded session.
6. Emergency Stop is separate from Victory, awards no XP, and intentionally overrides the challenge policy.

**Security note:** this is not a tamper-proof anti-cheat boundary. The native layer validates the completion payload shape and configured challenge set, but JavaScript-originated challenge evidence can be forged by a modified client. Stronger integrity would require moving puzzle secrets and verification into native code and/or hardware-backed attestation; neither proves physical presence. Photo dHash only measures visual resemblance.

## Permissions and platform limitations

- `SCHEDULE_EXACT_ALARM`: the app checks `canScheduleExactAlarms()` and fails scheduling with a useful message if denied. The user must grant access in system settings.
- `POST_NOTIFICATIONS`: Android 13+ runtime permission is needed for ordinary notification visibility.
- `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_MEDIA_PLAYBACK`: required for the ongoing media-playback foreground service.
- `USE_FULL_SCREEN_INTENT`: included, but full-screen intent use is subject to Android version, app eligibility and user/system settings. This source uses an ongoing notification with an open action; full-screen launch is not treated as guaranteed.
- `RECEIVE_BOOT_COMPLETED`, time/time-zone/package replacement receivers: attempt to reconstruct scheduled alarms after applicable system events. OEM restrictions may still apply.
- Force-stop, user force-quit, revoked permissions, battery-management policies, device shutdown and some manufacturer-specific task killers can prevent delivery or recovery. No Android app can honestly promise alarms after every force-stop/OS restriction.
- The service acquires a partial wake lock for at most 10 minutes per acquisition; the user must complete or recover the mission promptly. Review this bound for the product's desired alarm policy and Android background limits before release.
- A Web browser preview cannot provide locked-screen/background alarms. Native scheduling works only in the built Android app.

## Current feature coverage and known gaps

Implemented source includes the cyberpunk responsive dashboard, IndexedDB settings/media/victory stores, challenge selection, local dHash photo comparison, color ordering, memory sequence, export of JSON summary, state-machine module/tests, Kotlin scheduling/receiver/service/plugin source, and fallback tone.

Before calling this production-ready, finish and validate these items in Android Studio/device tests:

- Register the plugin permission alias for Android 13 notification permission and verify Capacitor 7 plugin API signatures against the resolved dependencies.
- Import the chosen browser audio file into native app-private storage using a native document picker; current web file upload persists locally for web settings but does not yet transfer its URI into native playback metadata.
- Complete native bridge event forwarding from service to WebView, native-side challenge secret/result verification, and persistent native victory/reward reconciliation across process death.
- Add an explicit Android UI flow for full-screen intent access if the product needs it, and validate lock-screen launch policy on target devices.
- Implement a complete restore flow for JSON exports; export currently covers settings summary and victories, not binary media.
- Add Android instrumentation tests and real-device verification. No hardware/emulator tests are claimed as passed by this source bundle.

## Tests

```bash
npm test
```

Unit tests cover deterministic luminance ordering, valid/invalid color sequences, reproducible memory sequences, dHash distance/similarity primitives and legal/illegal state transitions. They do not simulate Android alarm delivery, MediaPlayer, locked screen, reboot or OEM battery management.

## Manual device acceptance checklist

- [ ] Android 8–11: one-time alarm and weekday recurrence.
- [ ] Android 12+: grant/deny exact alarm permission and confirm accurate error reporting.
- [ ] Android 13+: grant/deny notification permission.
- [ ] Lock screen, background, display off, battery saver, and manufacturer battery settings.
- [ ] Reload/recreate WebView while ringing; verify one audio player and uninterrupted audio.
- [ ] Wrong color order, wrong memory order and failed photo comparison keep the alarm audible.
- [ ] Complete all selected challenges; verify audio stops only after accepted Victory.
- [ ] Repeat Victory callback; verify no duplicate reward.
- [ ] Reboot and change clock/time zone; verify rescheduling.
- [ ] Force Stop and document the expected Android limitation.
- [ ] Offline mode, invalid audio, missing reference photo, corrupt IndexedDB, storage quota.

## Troubleshooting

- **Gradle cannot find SDK:** set `ANDROID_HOME` / `ANDROID_SDK_ROOT`, install Platform 35 and Build Tools 35.x, then sync again.
- **Gradle/JDK mismatch:** use JDK 17 for AGP 8.7.x; verify `java -version` and Android Studio Gradle JDK.
- **Exact alarm not scheduled:** open Android Settings → Apps → Special app access → Alarms & reminders → MOJa ALARM; enable it and retry.
- **Notification missing:** enable app notifications in Android settings and re-check permission diagnostics.
- **Audio silent:** check alarm volume, DND/Audio focus, imported file format and native session `audioError`; use the bundled fallback tone.
- **Works while open only:** confirm the native APK is installed (not browser preview), foreground service declarations are present, and battery restrictions are understood.
- **Build output missing:** run `npx cap sync android`, then `cd android && ./gradlew assembleDebug`; inspect the first Gradle error, not only the final failure line.

## Cloud build from an Android phone (GitHub Actions)

This repository includes `.github/workflows/android-debug.yml`. The workflow runs JavaScript unit tests, stages the offline web assets, installs Android SDK Platform 35 and Build Tools 35.0.0, syncs Capacitor, and builds a debug APK. It uploads `MOJa-ALARM-debug-apk` as a workflow artifact for 14 days.

1. Extract the project ZIP on your phone and upload the **contents** of `MOJaAlarm/` to a new GitHub repository (for example, using GitHub's website or a mobile Git client). Include the hidden `.github/workflows/android-debug.yml` file.
2. Open the repository on GitHub → **Actions** → **MOJa ALARM Android Debug APK** → **Run workflow**. Alternatively, push to the `main` or `master` branch.
3. Wait for the workflow to finish. A green check means the automated workflow steps passed; it is not a claim of real-device alarm validation.
4. Open the successful workflow run, download the `MOJa-ALARM-debug-apk` artifact, extract the artifact ZIP, then install `app-debug.apk` on your phone. Allow installation from that source if Android asks.
5. On first launch, grant the requested permissions and test a short alarm while the phone is unlocked, then locked. Do not rely on this app for a critical alarm until device testing is complete.

No GitHub account or workflow has been created by this project bundle; you must upload the source and start the workflow from your own account. Never commit signing keys, passwords, or tokens.

The cloud workflow currently uses `npm install` because this source bundle does not contain a generated `package-lock.json`. For a release repository, run `npm install` once in a network-enabled development environment and commit the resulting lock file, then change the workflow to `npm ci` for deterministic dependency installation.

## Validation status of this source bundle

- Local JavaScript unit tests: **7/7 passed** in the available Node.js environment.
- Web staging script: can be checked locally with `npm run build:web` (does not require Android SDK).
- Android Gradle build: **not run here**; this environment does not have the Android SDK or Gradle installed, and network access to the package registry was unavailable during this session.
- Device tests (locked screen, reboot, exact-alarm access, audio focus, OEM battery restrictions): **not run**.

Known important limitation: the current native Victory validator checks the result payload's shape and configured challenge IDs, but cannot independently prove that a modified WebView genuinely solved the puzzle or that the camera image came from a live physical location. Treat this as a functional prototype until native-side challenge verification and the uploaded-ringtone import bridge are completed and reviewed.
