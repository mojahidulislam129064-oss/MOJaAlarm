import test from 'node:test';import assert from 'node:assert/strict';import {createStateMachine,STATES} from '../src/state-machine.js';
test('valid alarm lifecycle transitions',()=>{const m=createStateMachine();m.transition(STATES.SCHEDULED);m.transition(STATES.RINGING);m.transition(STATES.CHALLENGE_ARENA);m.transition(STATES.VICTORY);m.transition(STATES.IDLE);assert.equal(m.state,'IDLE')});
test('invalid transition is rejected',()=>{const m=createStateMachine();assert.throws(()=>m.transition(STATES.VICTORY),/Invalid state transition/)});
test('emergency stop is separate from victory',()=>{const m=createStateMachine(STATES.RINGING);m.transition(STATES.EMERGENCY_STOPPED);assert.equal(m.state,STATES.EMERGENCY_STOPPED);assert.equal(m.can(STATES.VICTORY),false)});
